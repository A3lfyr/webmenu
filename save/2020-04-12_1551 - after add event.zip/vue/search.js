var vue_search = new Vue({
    el: '#search',
    data: {
        searchEngine: null,
        searchUrl: null
    },
    methods: {
        getSearchUrl: function() {
            switch (this.searchEngine) {
                case "Bing":
                    this.searchUrl = "https://www.bing.com/search";
                    break;
    
                case "DuckDuck Go":
                    this.searchUrl = "https://duckduckgo.com/?";
                    break;

                case "Qwant":
                    this.searchUrl = "https://www.qwant.com/?q=";
                    break;
            
                default:
                    this.searchUrl = "https://www.google.com/search";
                    break;
            }
            return this.searchUrl;
        },
        getSearchEngine: function() {
            if(localStorage["searchEngine"] !== undefined){
                this.searchEngine = localStorage["searchEngine"];
            } else {
                this.searchEngine = "Google";
            }
        }
    },
    created() {
        setInterval(() => {
            this.searchUrl = this.getSearchUrl();
            this.searchEngin = this.getSearchEngine();
        }, 100)
    }
});