var vue_welcomeMessage = new Vue({
    el: '#quotes',
    data: {
        quote: {
            text: null,
            personnage: null,
            saison: null,
            episode: null
        }
    },
    methods: {
        getRandomQuote: function () {
            fetch("http://kaamelott.reiter.tf/api/random")
            .then(result => {
                return result.json();
            })
            .then(data => {
                this.quote.text = data.citation;
                this.quote.personnage = data.infos.personnage;
                this.quote.saison = data.infos.saison;
                this.quote.episode = data.infos.episode;
            })
            .catch(console.error)
        }
    },
    created() {
        this.getRandomQuote();
    }
});