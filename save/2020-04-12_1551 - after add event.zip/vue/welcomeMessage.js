var vue_welcomeMessage = new Vue({
    el: '#welcomeMessage',
    data: {
        message: ""
    },
    created() {
        setInterval(() => {
            this.message = this.getWelcomeMessage()
        }, 100000)
    },
    methods: {
        getWelcomeMessage: function () {
            hour = getHour(getTime());
            if (localStorage["name"] !== undefined) {
                name = localStorage["name"];
            } else {
                name = "";
            }
            if (hour >= 5 && hour <= 11) {
                return "Passez une bonne matinée " + name + " !";
            } else if (hour >= 11 && hour <= 17) {
                return "Passez une bonne journée " + name + " !";
            } else {
                return "Passez une bonne soirée " + name + " !";
            }
        }
    }
});