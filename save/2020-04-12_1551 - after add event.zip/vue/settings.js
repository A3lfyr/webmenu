var vue_welcomeMessage = new Vue({
    el: '#settings',
    data: {
        activePage: "",
        Settings: [
            {
                name: "General",
                Pages: [
                    {
                        name: "Dashboard",
                        data: {
                            username: null
                        }
                    },
                    {
                        name: "Recherches",
                        data: {
                            searchEngine: null
                        }
                    },
                    {
                        name: "Données locales",
                    }
                ]
            },
            {
                name: "Modules",
                Pages: [
                    {
                        name: "Météo",
                        enable: false,
                        data: {
                            theme: null,
                            latitude: null,
                            longitude: null
                        }
                    },
                    {
                        name: "Citation",
                        enable: false,
                        data: {
                        }
                    },
                    {
                        name: "Favoris",
                        enable: false,
                        data: {
                        }
                    }
                ]
            },
            {
                name: "Apparence",
                Pages: [
                    {
                        name: "Background",
                        data: {
                            theme: null
                        }
                    }
                ]
            },
            {
                name: "Credits",
                Pages: [
                    {
                        name: "Dev",
                    },
                    {
                        name: "API",
                    }
                ]
            }
        ]
    },
    methods: {
        changeActivePage: function(newPageName){
            this.activePage = newPageName;
        },
        getWeatherDisplay: function(){
            return this.Settings[1].Pages[0].enable;
        },
        setWeatherDisplay: function(state){
            this.Settings[1].Pages[0].enable = state;
            localStorage["displayWeather"] = state;
            EventManager.sendEvent(EventType.WEATHER_TOGGLE, state);
        },
        getQuoteDisplay: function(){
            return this.Settings[1].Pages[1].enable;
        },
        setQuoteDisplay: function(state){
            this.Settings[1].Pages[1].enable = state;
            localStorage["displayQuote"] = state;
        },
        getLinksDisplay: function(){
            return this.Settings[1].Pages[2].enable;
        },
        setLinksDisplay: function(state){
            this.Settings[1].Pages[2].enable = state;
            localStorage["displayLinks"] = state;
        },

        // SEARCH ENGINE
        getSearchEngine: function() {
            return this.Settings[0].Pages[1].searchEngine;
        },
        setSearchEngine: function(newSearchEngine) {
            this.Settings[0].Pages[1].searchEngine = newSearchEngine;
        },
        saveSearchEngine: function() {
            newSearchEngine = document.getElementById("searchEngineForme").value;
            this.setSearchEngine(newSearchEngine)
            localStorage["searchEngine"] = newSearchEngine;
        },

        // USERNAME
        getUsername: function() {
            return this.Settings[0].Pages[0].data.username;
        },
        setUsername: function(username) {
            this.Settings[0].Pages[0].data.username = username;
        },
        saveUsername: function(){
            newName = document.getElementById("nameForm").value;
            this.setUsername(newName)
            localStorage["name"] = newName;
        },
        // BACKGROUND THEME
        getBackgroundTheme: function() {
            return this.Settings[1].Pages[0].data.theme;
        },
        setBackgroundTheme: function(theme) {
            this.Settings[1].Pages[0].data.theme = theme;
        },
        saveBackgroundTheme: function() {
            newTheme = document.getElementById("themeForm").value.replace(/\s/g, '');
            this.setBackgroundTheme(newTheme);
            localStorage["bg_theme"] = newTheme;
        },
        
        // LATITUDE
        getLatitude: function() {
            return this.Settings[1].Pages[0].data.latitude;
        },
        setLatitude: function(latitude) {
            this.Settings[1].Pages[0].data.latitude = latitude;
        },
        saveLatitude: function() {
            newLatitude = document.getElementById("latitudeForm").value;
            this.setLatitude(newLatitude);
            localStorage["Latitude"] = newLatitude;
        },

        // LONGITUDE
        getLongitude: function() {
            return this.Settings[1].Pages[0].data.longitude;
        },
        setLongitude: function(longitude) {
            this.Settings[1].Pages[0].data.longitude = longitude;
        },
        saveLongitude: function() {
            newLongitude = document.getElementById("longitudeForm").value;
            this.setLongitude(newLongitude);
            localStorage["longitude"] = newLongitude;
        },

        // ENABLE-DISABLE

    },
    created() {
        if(localStorage["name"] !== undefined){
            this.setUsername(localStorage["name"]);
        }
        if(localStorage["bg_theme"] !== undefined){
            this.setBackgroundTheme(localStorage["bg_theme"]);
        }
        if(localStorage["latitude"] !== undefined){
            this.setLatitude(localStorage["latitude"]);
        }
        if(localStorage["longitude"] !== undefined){
            this.setLongitude(localStorage["longitude"]);
        }
        if(localStorage["searchEngine"] !== undefined){
            this.setSearchEngine(localStorage["searchEngine"]);
        } else {
            this.setSearchEngine("Google");
        }
        if(localStorage["displayWeather"] !== undefined){
            this.setWeatherDisplay(localStorage["displayWeather"]);
        } else {
            this.setWeatherDisplay(true);
        }
        this.activePage = "Dashboard";
        document.getElementById("nameForm").value = 2;
    }
});