const EventManager = new (class {
    constructor() {
        this.subscribers = new Array();
    }
    subscribe(subscriber) {
        this.subscribers.push(subscriber);
    }
    sendEvent(type, data) {
        this.subscribers.forEach(sub => {
            sub.onEvent(type, data);
        });
    }
})();

const EventType = {
    WEATHER_TOGGLE: 0
};