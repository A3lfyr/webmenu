function openNav() {
    document.getElementById("mySidepanel").style.width = "250px";
  }
  
  function closeNav() {
    document.getElementById("mySidepanel").style.width = "0";
  }


function openSetting() {
    document.getElementById("settings").classList.add("is-active");
}

function closeSetting() {
    document.getElementById("settings").classList.remove("is-active");
}

function saveSetting() {
    document.getElementById("settings").classList.remove("is-active");
}

function saveName() {
    localStorage["name"] = document.getElementById('nameForm').value;
}

function saveBackgroundTheme() {
    localStorage["bg_theme"] = document.getElementById('themeForm').value.replace(/\s/g, '');
}

function saveWeatherLatitude() {
    localStorage["latitude"] = document.getElementById('latitudeForm').value;
}

function saveWeatherLatitude() {
    localStorage["longitude"] = document.getElementById('longitudeForm').value;
}