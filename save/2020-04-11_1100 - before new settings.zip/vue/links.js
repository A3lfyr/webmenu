var vue_links = new Vue({
    el: '#links',
    data: {
        links: [{
                name: "Facebook",
                url: "http://facebook.com"
            },
            {
                name: "Site Perso",
                url: "http://reiter.tf"
            },
            {
                name: "Youtube",
                url: "http://youtube.com"
            }
        ]
    },
    methods: {

    },
    created() {}
});