var vue_welcomeMessage = new Vue({
    el: '#quotes',
    data: {
        quote: {
            text: "Je refuse d\u2019aller me battre pour soutenir une politique d\u2019expansion territoriale dont je ne reconnais pas la l\u00e9gitimit\u00e9.",
            author: "Yvain",
            saison: "Livre I",
            episode: "39 : Le Cas Yvain"
        }
    }
});