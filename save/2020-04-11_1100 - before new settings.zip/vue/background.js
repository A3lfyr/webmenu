var vue_background = new Vue({
    el: '#backgroundCredits',
    data: {
        backgroundImage: {
            url: null,
            link: null,
            author: null
        },
        theme: null,
        hour: null
    },
    methods: {
        getTimedTheme: function () {
            theme = "";
            if (this.hour >= 5 && this.hour <= 11) {
                theme = "morningcity";
            } else if (this.hour >= 11 && this.hour <= 17) {
                theme = "city";
            } else {
                theme = "nightcity";
            }
            return theme;
        },
        getBackgroundImage: function () {
            if (sessionStorage["bg_url"] !== undefined && sessionStorage["bg_link"] !== undefined && sessionStorage["bg_author"] !== undefined) {
                this.backgroundImage.url = sessionStorage["bg_url"];
                this.backgroundImage.link = sessionStorage["bg_link"];
                this.backgroundImage.author = sessionStorage["bg_author"];
            } else {
                fetch("https://api.unsplash.com/photos/random?query=" + this.theme + "&orientation=landscape&client_id=FVuyJtYxc_o9usr0a9_e_t1fR7dwHPWIgGgEzBErJGE")
                    .then(result => {
                        return result.json();
                    })
                    .then(data => {
                        this.backgroundImage.url = data.urls.regular;
                        this.backgroundImage.link = data.links.html;
                        this.backgroundImage.author = data.user.name;
                        sessionStorage["bg_url"] = this.backgroundImage.url;
                        sessionStorage["bg_link"] = this.backgroundImage.link;
                        sessionStorage["bg_author"] = this.backgroundImage.author;
                    })
                    .catch(console.error)
            }
            document.getElementById("main").style.background = "url(" + this.backgroundImage.url + ") no-repeat center fixed";
            document.getElementById("main").style.backgroundSize = "cover";
        }
    },
    created() {
        this.hour = getHour(getTime());
        if (localStorage["bg_theme"] !== undefined) {
            this.theme = localStorage["bg_theme"];
        } else {
            this.theme = this.getTimedTheme();
        }
        console.log("BG theme " + this.theme);
        this.getBackgroundImage();
    }
});