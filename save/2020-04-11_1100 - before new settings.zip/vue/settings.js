var vue_welcomeMessage = new Vue({
    el: '#settings',
    data: {
        name: "",
        theme: "",
        latitude: "",
        longitude: ""
    },
    created() {
        if (localStorage["name"] !== undefined) {
            this.name = localStorage["name"];
        }
        if (localStorage["bg_theme"] !== undefined) {
            this.theme = localStorage["bg_theme"];
        }
        if (localStorage["latitude"] !== undefined) {
            this.latitude = localStorage["latitude"];
        }
        if (localStorage["longitude"] !== undefined) {
            this.longitude = localStorage["longitude"];
        }
    }
});